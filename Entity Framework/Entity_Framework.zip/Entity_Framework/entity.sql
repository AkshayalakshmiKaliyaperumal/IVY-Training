create database netcore
use netcore

select * from __EFMigrationsHistory
select * from departments
select * from employees
